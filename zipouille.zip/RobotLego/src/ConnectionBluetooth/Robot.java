package ConnectionBluetooth;

import parcours.Node;

public class Robot {
	private Node caseDerriere;
	private Node caseActuelle;
	private int nombreVictimes = 0;
	
	public Robot(Node caseDepart, Node caseDerriere){
		this.caseActuelle = caseDepart;
		this.caseDerriere = caseDerriere;
	}
	
	public void recuperationVictime(){
		this.nombreVictimes++;
		System.out.println("Victime r�cup�r�e");
	}
	
	public void depotVictimes(){
		if(nombreVictimes > 1)
			System.out.println("Victimes d�pos�es");
		else if(nombreVictimes == 1)
			System.out.println("Victime d�pos�e");
		this.nombreVictimes = 0;
	}

	public Node getCaseDerriere() {
		return caseDerriere;
	}

	public void setCaseDerriere(Node caseDerriere) {
		this.caseDerriere = caseDerriere;
	}

	public Node getCaseActuelle() {
		return caseActuelle;
	}

	public void setCaseActuelle(Node caseActuelle) {
		this.caseActuelle = caseActuelle;
	}

	public int getNombreVictimes() {
		return nombreVictimes;
	}

	public void setNombreVictimes(int nombreVictimes) {
		this.nombreVictimes = nombreVictimes;
	}
	
}

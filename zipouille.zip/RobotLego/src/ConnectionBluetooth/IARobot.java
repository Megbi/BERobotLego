package ConnectionBluetooth;

import parcours.Node;
import parcours.TypeCase;

public class IARobot {
	public static void deplacement(Robot robot, Node destination){
		if(robot.getCaseActuelle().equals(destination)){
			System.out.println("Aucune action effectu�e");
		}
		else if(robot.getCaseDerriere().equals(destination)){
			//effectuer Demi-tour
			System.out.println("Le robot effectue Demi-tour");
		}
		else{
			if(robot.getCaseActuelle().getType() == TypeCase.SLIP){	// venir du join
				if(isSlipDroite(robot,destination)){
						//effectuer SlipDroit
						System.out.println("Le robot effectue SlipDroit");
					}
				else{
						//effectuer SlipGauche
						System.out.println("Le robot effectue SlipGauche");
					}
				}
			else{
				//effectuer AvancerF
				System.out.println("Le robot effectue AvancerF");
			}
		}
		robot.setCaseDerriere(robot.getCaseActuelle());
		robot.setCaseActuelle(destination);
	}
	
	public static boolean isSlipDroite(Robot robot, Node destination){
		int xDir = robot.getCaseActuelle().getX()-robot.getCaseDerriere().getX();
		int yDir = robot.getCaseActuelle().getY()-robot.getCaseDerriere().getY();
		int xDest = destination.getX()-robot.getCaseActuelle().getX();
		int yDest = destination.getY()-robot.getCaseActuelle().getY();
		int xVir = robot.getCaseActuelle().getX()-robot.getCaseActuelle().getSlipJoinX();
		int yVir = robot.getCaseActuelle().getY()-robot.getCaseActuelle().getSlipJoinY();
		
		if(yDir == -1){ // vient de la droite
			if(xDest == -1){
				return true;
			}
			else if(xDir == xDest && yDir == yDest){
				if(xVir == -1){
					return true;
				}
			}
		}
		else if(yDir == 1){ // vient de la gauche
			if(xDest == 1){
				return true;
			}
			else if(xDir == xDest && yDir == yDest){
				if(xVir == 1){
					return true;
				}
			}
		}
		else if(xDir == -1){ // vient du bas
			if(yDest == 1){
				return true;
			}
			else if(xDir == xDest && yDir == yDest){
				if(yVir == 1){
					return true;
				}
			}
		}
		else{ // vient du haut
			if(yDest == -1) {
				return true;
			}
			else if(xDir == xDest && yDir == yDest){
				if(yVir == -1){
					return true;
				}
			}
		}
		return false;
	}
}

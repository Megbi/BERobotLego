package parcours;

import ConnectionBluetooth.IARobot;
import ConnectionBluetooth.Robot;

public class MainParcours {

	public static void main(String[] args) {
		Node nodeStart = new Node("Empty", -1, -1, TypeCase.LIGNE, false, false);
		
		Node nodeA = new Node("A", 0, 0, TypeCase.LIGNE, false, false);
		Node nodeB = new Node("B", 0, 1, TypeCase.SLIP, false, false);
		Node nodeC = new Node("C", 1, 1, TypeCase.VIRAGE, false, false);
		Node nodeD = new Node("D", 1, 2, TypeCase.SLIP, false, false); 
		Node nodeE = new Node("E", 1, 3, TypeCase.VIRAGE, false, false);
		Node nodeF = new Node("F", 2, 0, TypeCase.LIGNE, false, false);
		Node nodeG = new Node("G", 2, 1, TypeCase.LIGNE, false, false);
		Node nodeH = new Node("H", 2, 2, TypeCase.SLIP, false, false);
		Node nodeI = new Node("I", 2, 3, TypeCase.VIRAGE, false, false);
		
		nodeB.setJointures(0, 0);
		nodeD.setJointures(2, 2);
		nodeH.setJointures(1, 2);

		nodeA.addDestination(nodeB, 1);
		
		nodeB.addDestination(nodeC, 1);
		
		nodeC.addDestination(nodeD, 1);
		
		nodeD.addDestination(nodeE, 1);
		nodeD.addDestination(nodeH, 1);
		
		nodeE.addDestination(nodeI, 1);
		
		nodeH.addDestination(nodeG, 1);
		
		nodeI.addDestination(nodeH, 1);
		
		nodeG.addDestination(nodeF, 1);

		Graph graph = new Graph();

		graph.addNode(nodeA);
		graph.addNode(nodeB);
		graph.addNode(nodeC);
		graph.addNode(nodeD);
		graph.addNode(nodeE);
		graph.addNode(nodeF);
		graph.addNode(nodeG);
		graph.addNode(nodeH);
		graph.addNode(nodeI);
		
		Node nodeDepart = nodeF;
		Node previousNode = nodeStart;
		Node nodeArrivee = nodeE;
		
		Robot robot = new Robot(nodeDepart, previousNode);
		
		graph = Dijkstra.calculateShortestPathFromSource(graph, nodeDepart);
		
		System.out.println("*** Parcours de "+nodeDepart.getName()+" vers "+nodeArrivee.getName()+" ***");
		
		for(Node n : nodeArrivee.getShortestPath()){ // ne pas prendre en compte l'�l�ment n�1
			
			//if(!robot.getCaseActuelle().equals(n)){
				System.out.println("- On part de la case "+robot.getCaseActuelle().getName()+" et on va" +
						" sur la case "+n.getName());
				IARobot.deplacement(robot,n);
			//}
		}
		System.out.println("- On touche au but, de la case "+robot.getCaseActuelle().getName()+" � la case "+nodeArrivee.getName());
		IARobot.deplacement(robot, nodeArrivee);
		System.out.println("Vous �tes arriv� sur la case "+nodeArrivee.getName()+", merci d'avoir fait confiance � OwOmega");
		
		/*
		System.out.println("");
		System.out.println("-----Test :-----");
		System.out.println("");
		
		System.out.println("Node D : "+IARobot.isSlipDroite(new Robot(nodeD, nodeH), nodeE));
		System.out.println("Node B : "+IARobot.isSlipDroite(new Robot(nodeB, nodeA), nodeC));
		System.out.println("Node H : "+IARobot.isSlipDroite(new Robot(nodeH, nodeD), nodeG));
		*/
	}

}

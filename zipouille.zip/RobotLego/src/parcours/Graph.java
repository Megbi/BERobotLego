package parcours;

import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;

public class Graph {

    private Set<Node> nodes = new HashSet<Node>();
    
    public void addNode(Node case0) {
    	nodes.add(case0);
    }

	public Set<Node> getCases() {
		return nodes;
	}

	public void setCases(Set<Node> cases) {
		this.nodes = cases;
	}

	public void resetDistance() {
		Iterator<Node> iter = this.nodes.iterator();
		/*do {
			
		} while (iter);*/
	}
    
    
    // getters and setters 
}
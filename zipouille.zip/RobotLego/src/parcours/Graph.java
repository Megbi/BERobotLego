package parcours;

import java.util.HashSet;
import java.util.Set;

public class Graph {

    private Set<Node> nodes = new HashSet<Node>();
    
    public void addNode(Node case0) {
    	nodes.add(case0);
    }

	public Set<Node> getCases() {
		return nodes;
	}

	public void setCases(Set<Node> cases) {
		this.nodes = cases;
	}

	// getters and setters 
}
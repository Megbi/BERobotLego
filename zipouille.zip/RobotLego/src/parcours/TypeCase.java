package parcours;

public enum TypeCase {
	VIRAGE, LIGNE, SLIP;
}
